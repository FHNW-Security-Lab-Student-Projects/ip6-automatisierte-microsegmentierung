class PathEngine:
    """Initialize with a topology; stores underlying NetworkX graph."""

    def __init__(self, topology: TopologyGraph):
        self.graph = topology.graph