# V(node, vlan) to Bool
self.V = {
    (node, vlan): Bool(f"V_{node}_{vlan}") for node in nodes for vlan in vlans
}