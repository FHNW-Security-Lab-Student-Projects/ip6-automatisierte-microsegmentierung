class TopologyGraph:
    def __init__(self):
        """Wrap a NetworkX graph for topology storage."""
        self.graph = nx.Graph()