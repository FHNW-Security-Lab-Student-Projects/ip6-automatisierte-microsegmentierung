@dataclass
class Edge:
    node_a: str
    node_b: str