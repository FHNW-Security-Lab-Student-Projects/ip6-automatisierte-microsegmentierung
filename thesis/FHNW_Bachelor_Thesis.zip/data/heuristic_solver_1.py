class SegmentationResult:
    def __init__(self):
        """
        Store bidirectional mappings: node to VLANs and VLAN to nodes.
        Uses defaultdicts for convenient incremental updates.
        """

        self.node_to_vlans = defaultdict(set)
        self.vlan_to_nodes = defaultdict(list)