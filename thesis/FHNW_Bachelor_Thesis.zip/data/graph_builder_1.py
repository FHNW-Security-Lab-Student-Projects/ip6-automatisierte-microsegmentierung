class NodeType(str, Enum):
    HOST = "host"
    SWITCH = "switch"


@dataclass
class Node:
    id: str
    type: NodeType