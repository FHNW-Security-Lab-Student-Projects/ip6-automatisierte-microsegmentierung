vlan_conditions = []

for v in self.vlans:
    cond = And(
        self.V[(c.src, v)],
        self.V[(c.dst, v)],
        *[self.V[(node, v)] for node in path],
    )
    vlan_conditions.append(cond)